//https://www.w3schools.com/howto/howto_js_trigger_button_enter.asp
function filtrelemeYap() {

  //--------------------------------------------------
  //Değişken tanımla.
  //--------------------------------------------------
  var input; 
  var filtreMetni; 
  var liste; 
  var listeDizi; 
  var aranan;
  var i;
  var a; 
  
  //--------------------------------------------------
  //Değişkenlere değer ata.
  //--------------------------------------------------
  input = document.getElementById("ara");
  filtreMetni = input.value.toLocaleLowerCase('tr-TR');
  liste = document.getElementById("liste");
  listeDizi = liste.getElementsByTagName("li");

  if (event.key === "Enter") {

    //--------------------------------------------------
    //li elementleri için döngü çalıştır.
    //--------------------------------------------------
    for (i = 0; i < listeDizi.length; i++) {

      //--------------------------------------------------
      //li elementi içindeki ilk a elementi için işlem yap.
      //--------------------------------------------------
      a = listeDizi[i].getElementsByTagName("a")[0];

      //--------------------------------------------------
      //Eğer a elementi varsa işlem yap.
      //--------------------------------------------------
      if (a) {
        aranan = a.textContent || a.innerText;
        if (aranan.toLocaleLowerCase('tr-TR').indexOf(filtreMetni) > -1) {
          listeDizi[i].style.display = "";
        } else {
          listeDizi[i].style.display = "none";
        }
      }
    }

    //--------------------------------------------------
    //input'u yeni arama için hazırla.
    //--------------------------------------------------
    input.select();
  }
}