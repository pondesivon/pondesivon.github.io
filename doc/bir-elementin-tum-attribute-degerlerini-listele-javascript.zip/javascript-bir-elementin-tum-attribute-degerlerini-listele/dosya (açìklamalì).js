function divAttrListele() {

    //--------------------------------------------------
    //Listelemek için unordered list (ul) kullanacağız.
    //Bunun için yeni bir ul nesnesi oluşturduk.
    //--------------------------------------------------
    var liste = document.createElement("ul");

    //--------------------------------------------------
    //div içindeki tüm özellikleri dizi olarak aldık.
    //--------------------------------------------------
    var divAttrDizi = document.getElementById("id-deger").attributes;

    //--------------------------------------------------
    //Şimdi bu özellikleri liste biçiminde
    //göstermek için döngü kullanacağız.
    //--------------------------------------------------
    for (var i = 0; i < divAttrDizi.length; i++) {
      
        //--------------------------------------------------
        //Her özelliği bir li içinde göstereceğiz.
        //Bu yüzden her seferinde yeni bir li elementimizi
        //oluşturup "li" adlı değişkene aktarıyoruz.
        //--------------------------------------------------
        var li = document.createElement("li");

        //--------------------------------------------------
        //Özelliklerin değerleri ile beraber
        //görüntülenmesini sağlıyoruz.
        //Örneğin görünüm bu şekilde olacak:
        //id = kapsayici
        //--------------------------------------------------
        var metin = divAttrDizi[i].name + " = " + divAttrDizi[i].value;

        //--------------------------------------------------
        //Oluşturduğumuz li elementinin içine
        //metin değişkenindeki değeri yazdırıyoruz.
        //--------------------------------------------------
        li.innerText = metin;

        //--------------------------------------------------
        //liste değişkeni bizim ul elementini oluşturup
        //aktardığımız değişkendi. ul içine li elementini
        //ekliyoruz.
        //--------------------------------------------------
        liste.appendChild(li);
    }

    //--------------------------------------------------
    //Burada da yukarıda tamamlanmış olan listeyi
    //html dosyamızın body etiketleri içine ekleme
    //işlemini yapmasını sağlıyoruz.
    //--------------------------------------------------
    document.body.appendChild(liste);
}



//--------------------------------------------------
//Yukarıdaki fonksiyon id değeri calistir olan
//butonun click olayı tetiklendiğinde çalışsın.
//--------------------------------------------------
document.getElementById("calistir").addEventListener(
    'click',
    divAttrListele
);