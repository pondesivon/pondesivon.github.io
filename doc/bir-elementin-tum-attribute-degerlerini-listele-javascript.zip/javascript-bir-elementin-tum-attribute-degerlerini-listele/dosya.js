function divAttrListele() {
    var liste = document.createElement("ul");
    var divAttrDizi = document.getElementById("id-deger").attributes;

    for (var i = 0; i < divAttrDizi.length; i++) {
        var li = document.createElement("li");
        var metin = divAttrDizi[i].name + " = " + divAttrDizi[i].value;
        li.innerText = metin;
        liste.appendChild(li);
    }

    document.body.appendChild(liste);
}

document.getElementById("calistir").addEventListener(
    'click',
    divAttrListele
);