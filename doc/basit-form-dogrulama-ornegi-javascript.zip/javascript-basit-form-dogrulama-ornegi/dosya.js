document.getElementById("submitBtn").addEventListener('click', send);
document.getElementById("clearForm").addEventListener('click', clear);

//--------------------------------------------------
//submitBtn id değerine sahip elemente tıklandığında
//formdaki verilerin gönderilmesini sağlayacak.
//--------------------------------------------------
function send() {
	validate();
	//document.getElementById("mainform").submit();
}

//--------------------------------------------------
//clearForm id değerine sahip elemente tıklandığında
//mainform id değerine sahip form elementi içindeki 
//tüm elementlerin içeriği temizlenecek.
//--------------------------------------------------
function clear() {
	document.getElementById("mainform").reset();
}

var validateMessage = "";
function validate() {
	var form = document.getElementById('mainform');
	var formElements = form.elements;

	for(var i=0; i<formElements.length; i++) {
		var element = formElements[i];
		if(element.type === "text" && element.value.length <= 0) {
			validateMessage += element.name + " boş bırakılamaz." + "\n\r";
		}
	}

	if(validateMessage.length > 0) {
		alert(validateMessage + "Gerekli alanları doldurunuz.");
	}
	validateMessage = "";
}