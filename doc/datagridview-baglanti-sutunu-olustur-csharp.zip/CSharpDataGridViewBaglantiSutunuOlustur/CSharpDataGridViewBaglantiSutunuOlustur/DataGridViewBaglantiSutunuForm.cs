﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpDataGridViewBaglantiSutunuOlustur
{
    public partial class DataGridViewBaglantiSutunuForm : Form
    {
        public DataGridViewBaglantiSutunuForm()
        {
            InitializeComponent();
        }

		void DataGridViewAyarla(DataGridView dataGridView)
		{
			dataGridView.ColumnCount = 2;

			dataGridView.Columns[0].Name = "Site Adı";
			dataGridView.Columns[0].Width = 120;
			
			dataGridView.Columns[1].Name = "Bağlantı";
			dataGridView.Columns[1].Width = 250;

			Dictionary<string, string> webSiteleri = new Dictionary<string, string>();
			webSiteleri.Add("Google", "https://www.google.com");
			webSiteleri.Add("GitHub", "https://github.com/");
			webSiteleri.Add("StackOverflow", "https://stackoverflow.com/");
			webSiteleri.Add("CodeProject", "https://www.codeproject.com/");

			foreach (KeyValuePair<string, string> item in webSiteleri)
	        {
				dataGridView.Rows.Add(item.Key, item.Value);
			}

			DataGridViewLinkColumn baglanti = new DataGridViewLinkColumn();
			baglanti.UseColumnTextForLinkValue = true;
			baglanti.HeaderText = "Bağlantı";
			baglanti.ActiveLinkColor = Color.Tomato;
			baglanti.LinkBehavior = LinkBehavior.SystemDefault;
			baglanti.LinkColor = Color.Blue;
			baglanti.TrackVisitedState = true;
			baglanti.VisitedLinkColor = Color.YellowGreen;
		}

        private void DataGridViewBaglantiSutunuForm_Load(object sender, EventArgs e)
        {
			DataGridViewAyarla(icerikDataGridView);
        }

        private void icerikDataGridView_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

		}

        private void icerikDataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
			if (e.ColumnIndex == 1)
			{
				string baglantiMetni =
					((System.Windows.Forms.DataGridView)(sender))
						.Rows[e.RowIndex]
						.Cells[e.ColumnIndex]
						.Value.ToString();

				if (baglantiMetni != null)
				{
					System.Diagnostics.Process.Start(baglantiMetni);
				}
			}
		}
    }
}
