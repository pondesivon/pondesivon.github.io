var parag = document.createElement("p");
var metin = document.createTextNode("appendChild ile eklendi.");

parag.appendChild(metin);

document.getElementsByClassName("content")[1].appendChild(parag);