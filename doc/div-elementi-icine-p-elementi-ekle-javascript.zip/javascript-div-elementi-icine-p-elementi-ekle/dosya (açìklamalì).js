//--------------------------------------------------
//Yeni bir p nesnesi oluştur ve değişkene ata.
//--------------------------------------------------
var parag = document.createElement("p");

//--------------------------------------------------
//Elementin içine yazdırmak için TextNode oluştur.
//--------------------------------------------------
var metin = document.createTextNode("appendChild ile eklendi.");

//--------------------------------------------------
//Metnin içine yazıyı ekle.
//Bunu innerText veya innerHTML ile de halledebilirdik 
//ama eklenecek metnin de element içindeki element gibi 
//davranması örneğini görebilmek için iyi oldu.
//--------------------------------------------------
parag.appendChild(metin);

//--------------------------------------------------
//p elementimizi aynı class'a sahip 
//div elementlerinden ikincisine ekle.
//--------------------------------------------------
document.getElementsByClassName("content")[1].appendChild(parag);