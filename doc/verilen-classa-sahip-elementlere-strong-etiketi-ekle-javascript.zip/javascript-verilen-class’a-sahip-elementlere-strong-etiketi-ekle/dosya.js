var listeOge = document.getElementsByClassName("lst");

for (var i = 0; i < listeOge.length; i++) {
    listeOge[i].innerHTML = "<strong>" 
							+ listeOge[i].innerText
							+ "</strong>";
}