﻿namespace CSharpCarpimTablosu
{
    partial class CarpimTablosuForm
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CarpimTablosuForm));
            this.carpimTablosuListView = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.kapsayiciToolStripContainer = new System.Windows.Forms.ToolStripContainer();
            this.ustToolStrip = new System.Windows.Forms.ToolStrip();
            this.seceneklerToolStripComboBox = new System.Windows.Forms.ToolStripComboBox();
            this.carpimTablosuOlusturToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.kapsayiciToolStripContainer.ContentPanel.SuspendLayout();
            this.kapsayiciToolStripContainer.TopToolStripPanel.SuspendLayout();
            this.kapsayiciToolStripContainer.SuspendLayout();
            this.ustToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // carpimTablosuListView
            // 
            this.carpimTablosuListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1});
            this.carpimTablosuListView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.carpimTablosuListView.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.carpimTablosuListView.HideSelection = false;
            this.carpimTablosuListView.Location = new System.Drawing.Point(0, 0);
            this.carpimTablosuListView.Name = "carpimTablosuListView";
            this.carpimTablosuListView.Size = new System.Drawing.Size(370, 388);
            this.carpimTablosuListView.TabIndex = 3;
            this.carpimTablosuListView.UseCompatibleStateImageBehavior = false;
            // 
            // kapsayiciToolStripContainer
            // 
            // 
            // kapsayiciToolStripContainer.ContentPanel
            // 
            this.kapsayiciToolStripContainer.ContentPanel.Controls.Add(this.carpimTablosuListView);
            this.kapsayiciToolStripContainer.ContentPanel.Size = new System.Drawing.Size(370, 388);
            this.kapsayiciToolStripContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kapsayiciToolStripContainer.Location = new System.Drawing.Point(0, 0);
            this.kapsayiciToolStripContainer.Name = "kapsayiciToolStripContainer";
            this.kapsayiciToolStripContainer.Size = new System.Drawing.Size(370, 421);
            this.kapsayiciToolStripContainer.TabIndex = 1;
            this.kapsayiciToolStripContainer.Text = "toolStripContainer1";
            // 
            // kapsayiciToolStripContainer.TopToolStripPanel
            // 
            this.kapsayiciToolStripContainer.TopToolStripPanel.Controls.Add(this.ustToolStrip);
            // 
            // ustToolStrip
            // 
            this.ustToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.ustToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.seceneklerToolStripComboBox,
            this.carpimTablosuOlusturToolStripButton});
            this.ustToolStrip.Location = new System.Drawing.Point(0, 0);
            this.ustToolStrip.Name = "ustToolStrip";
            this.ustToolStrip.Size = new System.Drawing.Size(370, 33);
            this.ustToolStrip.Stretch = true;
            this.ustToolStrip.TabIndex = 0;
            // 
            // seceneklerToolStripComboBox
            // 
            this.seceneklerToolStripComboBox.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.seceneklerToolStripComboBox.MaxDropDownItems = 10;
            this.seceneklerToolStripComboBox.Name = "seceneklerToolStripComboBox";
            this.seceneklerToolStripComboBox.Size = new System.Drawing.Size(121, 33);
            this.seceneklerToolStripComboBox.SelectedIndexChanged += new System.EventHandler(this.seceneklerToolStripComboBox_SelectedIndexChanged);
            this.seceneklerToolStripComboBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.seceneklerToolStripComboBox_KeyDown);
            // 
            // carpimTablosuOlusturToolStripButton
            // 
            this.carpimTablosuOlusturToolStripButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.carpimTablosuOlusturToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.carpimTablosuOlusturToolStripButton.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.carpimTablosuOlusturToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("carpimTablosuOlusturToolStripButton.Image")));
            this.carpimTablosuOlusturToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.carpimTablosuOlusturToolStripButton.Name = "carpimTablosuOlusturToolStripButton";
            this.carpimTablosuOlusturToolStripButton.Size = new System.Drawing.Size(213, 30);
            this.carpimTablosuOlusturToolStripButton.Text = "Çarpım Tablosu Oluştur";
            this.carpimTablosuOlusturToolStripButton.Click += new System.EventHandler(this.carpimTablosuOlusturToolStripButton_Click);
            // 
            // CarpimTablosuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(370, 421);
            this.Controls.Add(this.kapsayiciToolStripContainer);
            this.Name = "CarpimTablosuForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Çarpım Tablosu";
            this.Load += new System.EventHandler(this.CarpimTablosuForm_Load);
            this.kapsayiciToolStripContainer.ContentPanel.ResumeLayout(false);
            this.kapsayiciToolStripContainer.TopToolStripPanel.ResumeLayout(false);
            this.kapsayiciToolStripContainer.TopToolStripPanel.PerformLayout();
            this.kapsayiciToolStripContainer.ResumeLayout(false);
            this.kapsayiciToolStripContainer.PerformLayout();
            this.ustToolStrip.ResumeLayout(false);
            this.ustToolStrip.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ListView carpimTablosuListView;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ToolStripContainer kapsayiciToolStripContainer;
        private System.Windows.Forms.ToolStrip ustToolStrip;
        private System.Windows.Forms.ToolStripComboBox seceneklerToolStripComboBox;
        private System.Windows.Forms.ToolStripButton carpimTablosuOlusturToolStripButton;
    }
}

