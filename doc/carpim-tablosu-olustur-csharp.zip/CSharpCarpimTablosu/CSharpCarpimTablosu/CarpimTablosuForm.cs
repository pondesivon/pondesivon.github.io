﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpCarpimTablosu
{
    public partial class CarpimTablosuForm : Form
    {
        public CarpimTablosuForm()
        {
            InitializeComponent();
        }

        void CarpimTablosuListeleListView(ListView listView, int sayi)
        {
            try
            {
                listView.Items.Clear();
                listView.Columns.Clear();

                listView.View = View.Details;
                listView.FullRowSelect = true;
                listView.GridLines = true;
                listView.Columns.Add("Sayı 1", 100);
                listView.Columns.Add("*", 30);
                listView.Columns.Add("Sayı 2", 100);
                listView.Columns.Add("=", 30);
                listView.Columns.Add("Sonuç", 100);

                for (int i = 0; i < 10; i++)
                {
                    ListViewItem listViewItem = new ListViewItem();

                    listViewItem.Text = sayi.ToString();
                    listViewItem.SubItems.Add("*");
                    listViewItem.SubItems.Add(i.ToString());
                    listViewItem.SubItems.Add("=");
                    listViewItem.SubItems.Add((sayi * i).ToString());

                    listView.Items.Add(listViewItem);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void SayiListesiniYukle(ToolStripComboBox toolStripComboBox)
        {
            toolStripComboBox.Items.Clear();

            for (int i = 0; i < 20; i++)
            {
                toolStripComboBox.Items.Add((i + 1).ToString());
            }
        }

        void RasgeleCarpimTablosuOlustur()
        {
            Random random = new Random();
            int rasgeleSayi = random.Next(1, 100);

            CarpimTablosuListeleListView(
                carpimTablosuListView,
                rasgeleSayi);

            seceneklerToolStripComboBox.Text = rasgeleSayi.ToString();
            seceneklerToolStripComboBox.SelectAll();
            seceneklerToolStripComboBox.Focus();
        }

        private void CarpimTablosuForm_Load(object sender, EventArgs e)
        {
            SayiListesiniYukle(seceneklerToolStripComboBox);
            RasgeleCarpimTablosuOlustur();
        }

        private void seceneklerToolStripComboBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                CarpimTablosuListeleListView(
                    carpimTablosuListView,
                    Convert.ToInt32(seceneklerToolStripComboBox.Text));

                seceneklerToolStripComboBox.SelectAll();
            }
        }

        private void carpimTablosuOlusturToolStripButton_Click(object sender, EventArgs e)
        {
            CarpimTablosuListeleListView(
                carpimTablosuListView,
                Convert.ToInt32(seceneklerToolStripComboBox.Text));

            seceneklerToolStripComboBox.Focus();
            seceneklerToolStripComboBox.SelectAll();
        }

        private void seceneklerToolStripComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            CarpimTablosuListeleListView(
                carpimTablosuListView, 
                Convert.ToInt32(seceneklerToolStripComboBox.Text));
        }
    }
}
