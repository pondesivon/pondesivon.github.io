function PromptKullanarakCarpmaIslemiYap(){
	var sayi1 = prompt("Birinci sayıyı giriniz:", "");
	var sayi2 = prompt("İkinci sayıyı giriniz:", "");
	
	var sonuc = sayi1 * sayi2;
	document.write("İki sayının çarpımı: " + sonuc);
}