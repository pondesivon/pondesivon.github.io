<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>al.php - GET İle Gönderilen Veriyi Al</title>
</head>
<body>
	<?php
		$adi = $_GET["ad"];
		$soyadi = $_GET["soyad"];
		$e_posta = $_GET["eposta"];
		
		echo "Ad: ". $adi . " <br>";
		echo "Soyad: " . $soyadi . "<br>";
		echo "E Posta : " . $e_posta . "<br>";
	?>
</body>
</html>