<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>gonder.php - GET İle Başka Sayfaya Veri Gönder</title>
</head>
<body>
	<form action='al.php' method='get'>
		<table>
			<tr>
				<td>Ad</td>
				<td>Soyad</td>
				<td>Eposta<td>
			</tr>

			<tr>
				<td><input name='ad' type='text'></td>
				<td><input name='soyad' type='text'></td>
				<td><input name='eposta' type='text'><td>
			</tr>			
		</table>

		<!--------------------------------------------------
		Eğer aşağıdaki gönderme butonuna da name bilgisini
		dahil edersek $_GET metodu bu input için de çalışacaktır.
		---------------------------------------------------->
		<input type='submit' value='al.php sayfasına gönder'>
	</form>
</body>
</html>