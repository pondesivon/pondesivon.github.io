﻿
namespace CSharpBirSayininAsalBolenleriniBul
{
    partial class AsalBolenBulForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AsalBolenBulForm));
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.kapsayiciTableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.sonucListView = new System.Windows.Forms.ListView();
            this.asalBolenListView = new System.Windows.Forms.ListView();
            this.ustToolStrip = new System.Windows.Forms.ToolStrip();
            this.sayiToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.calistirToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.kapsayiciTableLayoutPanel.SuspendLayout();
            this.ustToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Controls.Add(this.kapsayiciTableLayoutPanel);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(365, 356);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(365, 383);
            this.toolStripContainer1.TabIndex = 0;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // toolStripContainer1.TopToolStripPanel
            // 
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.ustToolStrip);
            // 
            // kapsayiciTableLayoutPanel
            // 
            this.kapsayiciTableLayoutPanel.ColumnCount = 2;
            this.kapsayiciTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.kapsayiciTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.kapsayiciTableLayoutPanel.Controls.Add(this.sonucListView, 0, 0);
            this.kapsayiciTableLayoutPanel.Controls.Add(this.asalBolenListView, 1, 0);
            this.kapsayiciTableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kapsayiciTableLayoutPanel.Location = new System.Drawing.Point(0, 0);
            this.kapsayiciTableLayoutPanel.Name = "kapsayiciTableLayoutPanel";
            this.kapsayiciTableLayoutPanel.RowCount = 1;
            this.kapsayiciTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.kapsayiciTableLayoutPanel.Size = new System.Drawing.Size(365, 356);
            this.kapsayiciTableLayoutPanel.TabIndex = 0;
            // 
            // sonucListView
            // 
            this.sonucListView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sonucListView.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sonucListView.HideSelection = false;
            this.sonucListView.Location = new System.Drawing.Point(3, 3);
            this.sonucListView.Name = "sonucListView";
            this.sonucListView.Size = new System.Drawing.Size(176, 350);
            this.sonucListView.TabIndex = 0;
            this.sonucListView.UseCompatibleStateImageBehavior = false;
            // 
            // asalBolenListView
            // 
            this.asalBolenListView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.asalBolenListView.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.asalBolenListView.HideSelection = false;
            this.asalBolenListView.Location = new System.Drawing.Point(185, 3);
            this.asalBolenListView.Name = "asalBolenListView";
            this.asalBolenListView.Size = new System.Drawing.Size(177, 350);
            this.asalBolenListView.TabIndex = 0;
            this.asalBolenListView.UseCompatibleStateImageBehavior = false;
            this.asalBolenListView.Click += new System.EventHandler(this.asalBolenListView_Click);
            // 
            // ustToolStrip
            // 
            this.ustToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.ustToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sayiToolStripTextBox,
            this.calistirToolStripButton});
            this.ustToolStrip.Location = new System.Drawing.Point(0, 0);
            this.ustToolStrip.Name = "ustToolStrip";
            this.ustToolStrip.Size = new System.Drawing.Size(365, 27);
            this.ustToolStrip.Stretch = true;
            this.ustToolStrip.TabIndex = 0;
            // 
            // sayiToolStripTextBox
            // 
            this.sayiToolStripTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sayiToolStripTextBox.Name = "sayiToolStripTextBox";
            this.sayiToolStripTextBox.Size = new System.Drawing.Size(200, 27);
            this.sayiToolStripTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.sayiToolStripTextBox_KeyDown);
            // 
            // calistirToolStripButton
            // 
            this.calistirToolStripButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.calistirToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.calistirToolStripButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.calistirToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("calistirToolStripButton.Image")));
            this.calistirToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.calistirToolStripButton.Name = "calistirToolStripButton";
            this.calistirToolStripButton.Size = new System.Drawing.Size(136, 24);
            this.calistirToolStripButton.Text = "Asal Bölenleri Bul";
            this.calistirToolStripButton.Click += new System.EventHandler(this.calistirToolStripButton_Click);
            // 
            // AsalBolenBulForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 383);
            this.Controls.Add(this.toolStripContainer1);
            this.Name = "AsalBolenBulForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CSharp Sayının Asal Bölenlerini Bul";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.kapsayiciTableLayoutPanel.ResumeLayout(false);
            this.ustToolStrip.ResumeLayout(false);
            this.ustToolStrip.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.TableLayoutPanel kapsayiciTableLayoutPanel;
        private System.Windows.Forms.ListView sonucListView;
        private System.Windows.Forms.ListView asalBolenListView;
        private System.Windows.Forms.ToolStrip ustToolStrip;
        private System.Windows.Forms.ToolStripTextBox sayiToolStripTextBox;
        private System.Windows.Forms.ToolStripButton calistirToolStripButton;
    }
}

