﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpBirSayininAsalBolenleriniBul
{
    public partial class AsalBolenBulForm : Form
    {
        public AsalBolenBulForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ListViewAyar(sonucListView, "Sonuçlar");
            ListViewAyar(asalBolenListView, "Asal Bölenler");

            sayiToolStripTextBox.Focus();
            sayiToolStripTextBox.SelectionStart = 0;
        }

        void ListViewAyar(ListView listView, string sutunBasligi)
        {
            listView.Items.Clear();
            listView.Columns.Clear();

            listView.View = View.Details;
            listView.GridLines = true;
            listView.FullRowSelect = true;
            listView.Columns.Add(sutunBasligi, listView.Width);
        }

        void AsalBolenleriVeSonuclariListele(int bolunecekSayi, ListView lvw1, ListView lvw2)
        {
            try
            {
                int sayi = bolunecekSayi;
                int sonuc = bolunecekSayi;

                lvw1.Items.Clear();
                lvw2.Items.Clear();

                lvw2.Items.Add(sonuc.ToString());

                for (int i = 2; i <= sayi; i++)
                {
                    if (sonuc != 1 && sonuc % i == 0)
                    {
                        sonuc = sonuc / i;
                        ListViewItem liste_ogesi_bolen = new ListViewItem(i.ToString());
                        ListViewItem liste_ogesi_bolum = new ListViewItem(sonuc.ToString());

                        lvw1.Items.Add(liste_ogesi_bolen);
                        lvw2.Items.Add(liste_ogesi_bolum);
                        i = 1;
                    }
                }
            }
            catch (Exception istisna)
            {
                MessageBox.Show("Lütfen bir sayı giriniz.\n\nHata Açıklaması:\n" + istisna.Message.ToString());
            }
        }

        private void calistirToolStripButton_Click(object sender, EventArgs e)
        {
            AsalBolenleriVeSonuclariListele(
                Convert.ToInt32(sayiToolStripTextBox.Text),
                asalBolenListView,
                sonucListView);
        }

        private void asalBolenListView_Click(object sender, EventArgs e)
        {
            sonucListView.SelectedItems.Clear();
            sonucListView.Items[asalBolenListView.SelectedItems[0].Index].Selected = true;
            sonucListView.Items[asalBolenListView.SelectedItems[0].Index + 1].Selected = true;
        }

        private void sayiToolStripTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                AsalBolenleriVeSonuclariListele(
                    Convert.ToInt32(sayiToolStripTextBox.Text),
                    asalBolenListView,
                    sonucListView);
            }
        }
    }
}