<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>gonder.php - POST İle Başka Sayfaya Veri Gönder</title>
</head>
<body>
	<form action='al.php' method='post'>
		<table>
			<tr>
				<td>Ad</td>
				<td>Soyad</td>
				<td>Eposta<td>
			</tr>

			<tr>
				<td><input name='ad' type='text'></td>
				<td><input name='soyad' type='text'></td>
				<td><input name='eposta' type='text'><td>
			</tr>			
		</table>
		<input name='gonder' type='submit' value='al.php sayfasına gönder'>
	</form>
</body>
</html>