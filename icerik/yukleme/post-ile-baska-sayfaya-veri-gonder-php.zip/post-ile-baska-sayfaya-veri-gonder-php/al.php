<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>al.php - POST İle Gönderilen Veriyi Al</title>
</head>
<body>

		<?php
			$adi = $_POST["ad"];
			$soyadi = $_POST["soyad"];
			$e_posta = $_POST["eposta"];
			
			echo "Ad: ". $adi . " <br>";
			echo "Soyad: " . $soyadi . "<br>";
			echo "E Posta : " . $e_posta . "<br>";
		?>
</body>
</html>