function diziListele() {
	var dizi = [];
	var sayac = 0;
	
	var liste = document.createElement('ol');
	liste.setAttribute("id", "array-lst");
	document.getElementById("content").appendChild(liste);
	
	for(var i=10; i<=100; i+=10) {
		dizi[sayac] = i;

		var listeOgesi = document.createElement('li');
		listeOgesi.setAttribute("id", "oge-" + sayac);
		sayac++;
		listeOgesi.innerHTML = i + ". değer";
		document.getElementById("array-lst").appendChild(listeOgesi);
	}
}