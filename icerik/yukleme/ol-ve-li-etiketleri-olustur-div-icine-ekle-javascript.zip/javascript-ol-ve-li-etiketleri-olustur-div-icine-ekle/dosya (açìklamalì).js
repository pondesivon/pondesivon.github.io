function diziListele() {
	var dizi = [];
	var sayac = 0;
	
	//--------------------------------------------------
	//Element oluşturduk.
	//--------------------------------------------------
	var liste = document.createElement('ol');
	
	//--------------------------------------------------
	//Elemente id değerini verdik. (Attribute)
	//--------------------------------------------------
	liste.setAttribute("id", "array-lst");
	
	//--------------------------------------------------
	//liste isimli elementi id değeri "content" olan 
	//elemente alt eleman olarak ekle. 
	//Yani div'in içine ol etiketi ekledik.
	//--------------------------------------------------
	document.getElementById("content").appendChild(liste);
	
	for(var i=10; i<=100; i+=10) {
		dizi[sayac] = i;
		
		//--------------------------------------------------
		//ol elementine diziyi eklemek için li etiketlerini
		//kullanacağız. li elementini oluşturduk.
		//--------------------------------------------------
		var listeOgesi = document.createElement('li');
		
		//--------------------------------------------------
		//li elementi için birden fazla attribute ayarladık.
		//--------------------------------------------------
		listeOgesi.setAttribute("id", "oge-" + sayac);
		listeOgesi.setAttribute("class", "stil1");
		sayac++;
		
		//--------------------------------------------------
		//<li></li> etiketleri içine bir şeyler 
		//yazdırmak için bunu kullandık.
		//--------------------------------------------------
		listeOgesi.innerHTML = i + ". değer";
		
		//--------------------------------------------------
		//Şimdi döngü ile <li>Değerler</li> şeklinde elementleri
		//düzenledik ama bizim istediğimiz ol etiket içinde de
		//listelenmesi gerekiyor. Yukarıda zaten "array-lst" id
		//değerine sahip bir ol elementi oluşturmuştuk. Şimdi
		//döngü ile sırayla oluşturulan li elementini yine 
		//sırayla eklenmesini sağlayalım.
		//--------------------------------------------------
		document.getElementById("array-lst").appendChild(listeOgesi);
	}
}