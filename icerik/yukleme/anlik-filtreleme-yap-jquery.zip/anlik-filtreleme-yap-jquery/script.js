$('#filtre').keyup(function () {
	if ($('#filtre').val().length < 2) {
		var tg = $('.liste-ogesi');
		tg.show();
		$(".sayac").html("Toplam <strong>" + tg.length + "</strong> kişi gösteriliyor.");
		return;
	}
	$('.liste-ogesi').hide();

	var txt = $('#filtre').val();
	$('.liste-ogesi').each(function () {
		if ($(this).text().toUpperCase().indexOf(txt.toUpperCase()) != -1) {
			$(this).show();
		}
	});
	var t = $('.liste-ogesi:visible');
	$(".sayac").html("Toplam <strong>" + t.length + "</strong> kişi gösteriliyor.");
});

function ekle(liste) {
	var deger = document.getElementsByClassName(liste);
	var dizi = deger[0].value.split('\n');
	for (var i = 0; i < dizi.length; i++) {
		var parag = document.createElement("div");
		parag.setAttribute("class", "liste-ogesi");

		var metin = document.createTextNode(dizi[i]);
		parag.appendChild(metin);

		document.getElementsByClassName("container")[0].appendChild(parag);
	}
}