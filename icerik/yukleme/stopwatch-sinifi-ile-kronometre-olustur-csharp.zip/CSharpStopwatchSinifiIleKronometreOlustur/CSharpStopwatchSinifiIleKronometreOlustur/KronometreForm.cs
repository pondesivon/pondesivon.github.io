﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpStopwatchSinifiIleKronometreOlustur
{
    public partial class KronometreForm : Form
    {
        public KronometreForm()
        {
            InitializeComponent();
        }

        public Stopwatch Kronometre { get; set; } = new Stopwatch();

        string GecenZaman(Stopwatch stopwatch, byte hassasiyet = 4)
        {
            TimeSpan ts = stopwatch.Elapsed;

            if (hassasiyet >= 4)
            {
                return ts.ToString();
            }
            else if (hassasiyet == 3)
            {
                return String.Format(
                    "{0:00}:{1:00}:{2:00}.{3:000}",
                    ts.Hours,
                    ts.Minutes,
                    ts.Seconds,
                    ts.Milliseconds / 1);
            }
            else if (hassasiyet == 2)
            {
                return String.Format(
                    "{0:00}:{1:00}:{2:00}.{3:00}",
                    ts.Hours, 
                    ts.Minutes, 
                    ts.Seconds, 
                    ts.Milliseconds / 10);
            }
           else if (hassasiyet == 1)
            {
                return String.Format(
                    "{0:00}:{1:00}:{2:00}.{3:0}",
                    ts.Hours, 
                    ts.Minutes, 
                    ts.Seconds, 
                    ts.Milliseconds / 100);
            }
            else if (hassasiyet == 0)
            {
                return String.Format(
                    "{0:00}:{1:00}:{2:00}",
                    ts.Hours,
                    ts.Minutes,
                    ts.Seconds);
            }
            else
            {
                return ts.ToString();
            }
        }

        private void kronometreTimer_Tick(object sender, EventArgs e)
        {
            kronometreSifirLabel.Text = GecenZaman(Kronometre, 0);
            kronometreBirLabel.Text = GecenZaman(Kronometre, 1);
            kronometreIkiLabel.Text = GecenZaman(Kronometre, 2);
            kronometreUcLabel.Text = GecenZaman(Kronometre, 3);
            kronometreDortLabel.Text = GecenZaman(Kronometre, 4);
        }

        private void baslatButton_Click(object sender, EventArgs e)
        {
            kronometreTimer.Interval = 1;
            kronometreTimer.Start();
            Kronometre.Start();
        }

        private void duraklatButton_Click(object sender, EventArgs e)
        {
            Kronometre.Stop();
        }

        private void sifirlaButton_Click(object sender, EventArgs e)
        {
            Kronometre.Reset();
            kronometreTimer.Stop();

            kronometreSifirLabel.Text = "00:00:00";
            kronometreBirLabel.Text = "00:00:00.0";
            kronometreIkiLabel.Text = "00:00:00.00";
            kronometreUcLabel.Text = "00:00:00.000";
            kronometreDortLabel.Text = "00:00:00.0000000";
        }

        private void sifirlaVeBaslatButton_Click(object sender, EventArgs e)
        {
            Kronometre.Restart();
        }
    }
}