﻿
namespace CSharpStopwatchSinifiIleKronometreOlustur
{
    partial class KronometreForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kapsayiciTableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.kronometreSifirLabel = new System.Windows.Forms.Label();
            this.kronometreBirLabel = new System.Windows.Forms.Label();
            this.kronometreIkiLabel = new System.Windows.Forms.Label();
            this.kronometreUcLabel = new System.Windows.Forms.Label();
            this.kronometreDortLabel = new System.Windows.Forms.Label();
            this.altTableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.baslatButton = new System.Windows.Forms.Button();
            this.duraklatButton = new System.Windows.Forms.Button();
            this.sifirlaButton = new System.Windows.Forms.Button();
            this.sifirlaVeBaslatButton = new System.Windows.Forms.Button();
            this.kronometreTimer = new System.Windows.Forms.Timer(this.components);
            this.kapsayiciTableLayoutPanel.SuspendLayout();
            this.altTableLayoutPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // kapsayiciTableLayoutPanel
            // 
            this.kapsayiciTableLayoutPanel.ColumnCount = 1;
            this.kapsayiciTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.kapsayiciTableLayoutPanel.Controls.Add(this.kronometreSifirLabel, 0, 0);
            this.kapsayiciTableLayoutPanel.Controls.Add(this.kronometreBirLabel, 0, 1);
            this.kapsayiciTableLayoutPanel.Controls.Add(this.kronometreIkiLabel, 0, 2);
            this.kapsayiciTableLayoutPanel.Controls.Add(this.kronometreUcLabel, 0, 3);
            this.kapsayiciTableLayoutPanel.Controls.Add(this.kronometreDortLabel, 0, 4);
            this.kapsayiciTableLayoutPanel.Controls.Add(this.altTableLayoutPanel, 0, 5);
            this.kapsayiciTableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kapsayiciTableLayoutPanel.Location = new System.Drawing.Point(0, 0);
            this.kapsayiciTableLayoutPanel.Name = "kapsayiciTableLayoutPanel";
            this.kapsayiciTableLayoutPanel.RowCount = 6;
            this.kapsayiciTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.kapsayiciTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.kapsayiciTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.kapsayiciTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.kapsayiciTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.kapsayiciTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.kapsayiciTableLayoutPanel.Size = new System.Drawing.Size(423, 391);
            this.kapsayiciTableLayoutPanel.TabIndex = 0;
            // 
            // kronometreSifirLabel
            // 
            this.kronometreSifirLabel.AutoSize = true;
            this.kronometreSifirLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.kronometreSifirLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kronometreSifirLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kronometreSifirLabel.Location = new System.Drawing.Point(3, 0);
            this.kronometreSifirLabel.Name = "kronometreSifirLabel";
            this.kronometreSifirLabel.Size = new System.Drawing.Size(417, 65);
            this.kronometreSifirLabel.TabIndex = 0;
            this.kronometreSifirLabel.Text = "00:00:00";
            // 
            // kronometreBirLabel
            // 
            this.kronometreBirLabel.AutoSize = true;
            this.kronometreBirLabel.BackColor = System.Drawing.Color.Silver;
            this.kronometreBirLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kronometreBirLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kronometreBirLabel.Location = new System.Drawing.Point(3, 65);
            this.kronometreBirLabel.Name = "kronometreBirLabel";
            this.kronometreBirLabel.Size = new System.Drawing.Size(417, 65);
            this.kronometreBirLabel.TabIndex = 0;
            this.kronometreBirLabel.Text = "00:00:00.0";
            // 
            // kronometreIkiLabel
            // 
            this.kronometreIkiLabel.AutoSize = true;
            this.kronometreIkiLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.kronometreIkiLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kronometreIkiLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kronometreIkiLabel.Location = new System.Drawing.Point(3, 130);
            this.kronometreIkiLabel.Name = "kronometreIkiLabel";
            this.kronometreIkiLabel.Size = new System.Drawing.Size(417, 65);
            this.kronometreIkiLabel.TabIndex = 0;
            this.kronometreIkiLabel.Text = "00:00:00.00";
            // 
            // kronometreUcLabel
            // 
            this.kronometreUcLabel.AutoSize = true;
            this.kronometreUcLabel.BackColor = System.Drawing.Color.Silver;
            this.kronometreUcLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kronometreUcLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kronometreUcLabel.Location = new System.Drawing.Point(3, 195);
            this.kronometreUcLabel.Name = "kronometreUcLabel";
            this.kronometreUcLabel.Size = new System.Drawing.Size(417, 65);
            this.kronometreUcLabel.TabIndex = 0;
            this.kronometreUcLabel.Text = "00:00:00.000";
            // 
            // kronometreDortLabel
            // 
            this.kronometreDortLabel.AutoSize = true;
            this.kronometreDortLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.kronometreDortLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kronometreDortLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kronometreDortLabel.Location = new System.Drawing.Point(3, 260);
            this.kronometreDortLabel.Name = "kronometreDortLabel";
            this.kronometreDortLabel.Size = new System.Drawing.Size(417, 65);
            this.kronometreDortLabel.TabIndex = 0;
            this.kronometreDortLabel.Text = "00:00:00.0000000";
            // 
            // altTableLayoutPanel
            // 
            this.altTableLayoutPanel.ColumnCount = 4;
            this.altTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.altTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.altTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.altTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.altTableLayoutPanel.Controls.Add(this.baslatButton, 3, 0);
            this.altTableLayoutPanel.Controls.Add(this.duraklatButton, 2, 0);
            this.altTableLayoutPanel.Controls.Add(this.sifirlaButton, 1, 0);
            this.altTableLayoutPanel.Controls.Add(this.sifirlaVeBaslatButton, 0, 0);
            this.altTableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.altTableLayoutPanel.Location = new System.Drawing.Point(3, 328);
            this.altTableLayoutPanel.Name = "altTableLayoutPanel";
            this.altTableLayoutPanel.RowCount = 1;
            this.altTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.altTableLayoutPanel.Size = new System.Drawing.Size(417, 60);
            this.altTableLayoutPanel.TabIndex = 1;
            // 
            // baslatButton
            // 
            this.baslatButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.baslatButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.baslatButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.baslatButton.Location = new System.Drawing.Point(315, 3);
            this.baslatButton.Name = "baslatButton";
            this.baslatButton.Size = new System.Drawing.Size(99, 54);
            this.baslatButton.TabIndex = 0;
            this.baslatButton.Text = "BAŞLAT";
            this.baslatButton.UseVisualStyleBackColor = false;
            this.baslatButton.Click += new System.EventHandler(this.baslatButton_Click);
            // 
            // duraklatButton
            // 
            this.duraklatButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.duraklatButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.duraklatButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.duraklatButton.Location = new System.Drawing.Point(211, 3);
            this.duraklatButton.Name = "duraklatButton";
            this.duraklatButton.Size = new System.Drawing.Size(98, 54);
            this.duraklatButton.TabIndex = 0;
            this.duraklatButton.Text = "DURAKLAT";
            this.duraklatButton.UseVisualStyleBackColor = false;
            this.duraklatButton.Click += new System.EventHandler(this.duraklatButton_Click);
            // 
            // sifirlaButton
            // 
            this.sifirlaButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.sifirlaButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sifirlaButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sifirlaButton.Location = new System.Drawing.Point(107, 3);
            this.sifirlaButton.Name = "sifirlaButton";
            this.sifirlaButton.Size = new System.Drawing.Size(98, 54);
            this.sifirlaButton.TabIndex = 0;
            this.sifirlaButton.Text = "SIFIRLA";
            this.sifirlaButton.UseVisualStyleBackColor = false;
            this.sifirlaButton.Click += new System.EventHandler(this.sifirlaButton_Click);
            // 
            // sifirlaVeBaslatButton
            // 
            this.sifirlaVeBaslatButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.sifirlaVeBaslatButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sifirlaVeBaslatButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sifirlaVeBaslatButton.Location = new System.Drawing.Point(3, 3);
            this.sifirlaVeBaslatButton.Name = "sifirlaVeBaslatButton";
            this.sifirlaVeBaslatButton.Size = new System.Drawing.Size(98, 54);
            this.sifirlaVeBaslatButton.TabIndex = 0;
            this.sifirlaVeBaslatButton.Text = "SIFIRLA\r\nVE\r\nBAŞLAT";
            this.sifirlaVeBaslatButton.UseVisualStyleBackColor = false;
            this.sifirlaVeBaslatButton.Click += new System.EventHandler(this.sifirlaVeBaslatButton_Click);
            // 
            // kronometreTimer
            // 
            this.kronometreTimer.Interval = 1000;
            this.kronometreTimer.Tick += new System.EventHandler(this.kronometreTimer_Tick);
            // 
            // KronometreForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(423, 391);
            this.Controls.Add(this.kapsayiciTableLayoutPanel);
            this.Name = "KronometreForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kronometre";
            this.kapsayiciTableLayoutPanel.ResumeLayout(false);
            this.kapsayiciTableLayoutPanel.PerformLayout();
            this.altTableLayoutPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel kapsayiciTableLayoutPanel;
        private System.Windows.Forms.Label kronometreSifirLabel;
        private System.Windows.Forms.Label kronometreBirLabel;
        private System.Windows.Forms.Label kronometreIkiLabel;
        private System.Windows.Forms.Label kronometreUcLabel;
        private System.Windows.Forms.Label kronometreDortLabel;
        private System.Windows.Forms.TableLayoutPanel altTableLayoutPanel;
        private System.Windows.Forms.Button baslatButton;
        private System.Windows.Forms.Button duraklatButton;
        private System.Windows.Forms.Button sifirlaButton;
        private System.Windows.Forms.Button sifirlaVeBaslatButton;
        private System.Windows.Forms.Timer kronometreTimer;
    }
}

