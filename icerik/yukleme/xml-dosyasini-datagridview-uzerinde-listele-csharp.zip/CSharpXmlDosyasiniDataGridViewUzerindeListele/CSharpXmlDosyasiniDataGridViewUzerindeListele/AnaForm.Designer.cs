﻿
namespace CSharpXmlDosyasiniDataGridViewUzerindeListele
{
    partial class AnaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listeDataGridView = new System.Windows.Forms.DataGridView();
            this.listeleButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.listeDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // listeDataGridView
            // 
            this.listeDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.listeDataGridView.Location = new System.Drawing.Point(12, 12);
            this.listeDataGridView.Name = "listeDataGridView";
            this.listeDataGridView.Size = new System.Drawing.Size(611, 150);
            this.listeDataGridView.TabIndex = 0;
            // 
            // listeleButton
            // 
            this.listeleButton.Location = new System.Drawing.Point(460, 168);
            this.listeleButton.Name = "listeleButton";
            this.listeleButton.Size = new System.Drawing.Size(163, 37);
            this.listeleButton.TabIndex = 1;
            this.listeleButton.Text = "Listele";
            this.listeleButton.UseVisualStyleBackColor = true;
            this.listeleButton.Click += new System.EventHandler(this.listeleButton_Click);
            // 
            // AnaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(635, 217);
            this.Controls.Add(this.listeleButton);
            this.Controls.Add(this.listeDataGridView);
            this.Name = "AnaForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "XML Dosyasını DataGridView Üzerinde Listele";
            ((System.ComponentModel.ISupportInitialize)(this.listeDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView listeDataGridView;
        private System.Windows.Forms.Button listeleButton;
    }
}

