﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace CSharpXmlDosyasiniDataGridViewUzerindeListele
{
    public partial class AnaForm : Form
    {
        public AnaForm()
        {
            InitializeComponent();
        }

        void Listele(string xmlDosyasi, DataGridView dataGridView)
        {
            //--------------------------------------------------
            //DataGridView için otomatik boyutlandırma yapıyoruz.
            //--------------------------------------------------
            dataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;

            //--------------------------------------------------
            //DataGridView'e dataset üzerinden aktarma
            //yapacağımız için DataSet örneği oluşturduk.
            //--------------------------------------------------
            DataSet veri_seti = new DataSet();

            //--------------------------------------------------
            //XML dosyasını okutabilmek için System.Xml
            //isim alanındaki XmlReader sınıfından bir
            //örnek oluşturuyoruz.
            //--------------------------------------------------
            XmlReader xml_dosyasi;

            //--------------------------------------------------
            //Okutacağımız XML dosyası için dosya yolunu tanımladık.
            //--------------------------------------------------
            xml_dosyasi = XmlReader.Create(xmlDosyasi);

            //--------------------------------------------------
            //XML dosyamızı okutuyoruz.
            //--------------------------------------------------
            veri_seti.ReadXml(xml_dosyasi);

            //--------------------------------------------------
            //Verilerimizi DataGridView'da listeliyoruz.
            //--------------------------------------------------
            dataGridView.DataSource = veri_seti.Tables[0];
        }

        private void listeleButton_Click(object sender, EventArgs e)
        {
            string xmlDosyasi = Path.Combine(Application.StartupPath, "WebSiteleri.xml");
            Listele(xmlDosyasi, listeDataGridView);
        }
    }
}
