﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpBubbleSortIleSiralamaYap
{
    public partial class BubbleSortIleSiralamaYapForm : Form
    {
        public BubbleSortIleSiralamaYapForm()
        {
            InitializeComponent();
        }

        int[] BubbleSortIleSiralamaYap(int[] dizi)
        {
            int gecici_degisken;

            for (int i = 0; i <= dizi.Length - 1; i++)
            {
                for (int j = 0; j <= dizi.Length - 1; j++)
                {
                    if (dizi[j] > dizi[i] && i != j)
                    {
                        gecici_degisken = dizi[j];
                        dizi[j] = dizi[i];
                        dizi[i] = gecici_degisken;
                        gecici_degisken = 0;
                    }
                }
            }
            return dizi;
        }

        public int[] sayiDizi = new int[] { 1, 5, 10, 8, 12, 24, 18 };

        private void BubbleSortIleSiralamaYapForm_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < sayiDizi.Length; i++)
            {
                sayiListesiKarisikListBox.Items.Add(sayiDizi[i]);
            }
        }

        private void bubbleSortIleSiralaButton_Click(object sender, EventArgs e)
        {
            int[] sonucDizi = BubbleSortIleSiralamaYap(sayiDizi);

            sayiListesiSiraliListBox.Items.Clear();

            for (int i = 0; i < sonucDizi.Length; i++)
            {
                sayiListesiSiraliListBox.Items.Add(sonucDizi[i]);
            }
        }
    }
}
