﻿
namespace CSharpBubbleSortIleSiralamaYap
{
    partial class BubbleSortIleSiralamaYapForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.kapsayiciTableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.sayiListesiKarisikListBox = new System.Windows.Forms.ListBox();
            this.sayiListesiSiraliListBox = new System.Windows.Forms.ListBox();
            this.bubbleSortIleSiralaButton = new System.Windows.Forms.Button();
            this.kapsayiciTableLayoutPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // kapsayiciTableLayoutPanel
            // 
            this.kapsayiciTableLayoutPanel.ColumnCount = 2;
            this.kapsayiciTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.kapsayiciTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.kapsayiciTableLayoutPanel.Controls.Add(this.sayiListesiKarisikListBox, 0, 0);
            this.kapsayiciTableLayoutPanel.Controls.Add(this.sayiListesiSiraliListBox, 1, 0);
            this.kapsayiciTableLayoutPanel.Controls.Add(this.bubbleSortIleSiralaButton, 1, 1);
            this.kapsayiciTableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kapsayiciTableLayoutPanel.Location = new System.Drawing.Point(0, 0);
            this.kapsayiciTableLayoutPanel.Name = "kapsayiciTableLayoutPanel";
            this.kapsayiciTableLayoutPanel.RowCount = 2;
            this.kapsayiciTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.kapsayiciTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.kapsayiciTableLayoutPanel.Size = new System.Drawing.Size(320, 232);
            this.kapsayiciTableLayoutPanel.TabIndex = 0;
            // 
            // sayiListesiKarisikListBox
            // 
            this.sayiListesiKarisikListBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sayiListesiKarisikListBox.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sayiListesiKarisikListBox.FormattingEnabled = true;
            this.sayiListesiKarisikListBox.ItemHeight = 24;
            this.sayiListesiKarisikListBox.Location = new System.Drawing.Point(3, 3);
            this.sayiListesiKarisikListBox.Name = "sayiListesiKarisikListBox";
            this.sayiListesiKarisikListBox.Size = new System.Drawing.Size(154, 179);
            this.sayiListesiKarisikListBox.TabIndex = 4;
            // 
            // sayiListesiSiraliListBox
            // 
            this.sayiListesiSiraliListBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sayiListesiSiraliListBox.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sayiListesiSiraliListBox.FormattingEnabled = true;
            this.sayiListesiSiraliListBox.ItemHeight = 24;
            this.sayiListesiSiraliListBox.Location = new System.Drawing.Point(163, 3);
            this.sayiListesiSiraliListBox.Name = "sayiListesiSiraliListBox";
            this.sayiListesiSiraliListBox.Size = new System.Drawing.Size(154, 179);
            this.sayiListesiSiraliListBox.TabIndex = 5;
            // 
            // bubbleSortIleSiralaButton
            // 
            this.bubbleSortIleSiralaButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bubbleSortIleSiralaButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bubbleSortIleSiralaButton.Location = new System.Drawing.Point(163, 188);
            this.bubbleSortIleSiralaButton.Name = "bubbleSortIleSiralaButton";
            this.bubbleSortIleSiralaButton.Size = new System.Drawing.Size(154, 41);
            this.bubbleSortIleSiralaButton.TabIndex = 6;
            this.bubbleSortIleSiralaButton.Text = "BUBBLE SORT İLE SIRALA";
            this.bubbleSortIleSiralaButton.UseVisualStyleBackColor = false;
            this.bubbleSortIleSiralaButton.Click += new System.EventHandler(this.bubbleSortIleSiralaButton_Click);
            // 
            // BubbleSortIleSiralamaYapForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(320, 232);
            this.Controls.Add(this.kapsayiciTableLayoutPanel);
            this.Name = "BubbleSortIleSiralamaYapForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bubble Sort İle Sıralama Yap";
            this.Load += new System.EventHandler(this.BubbleSortIleSiralamaYapForm_Load);
            this.kapsayiciTableLayoutPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel kapsayiciTableLayoutPanel;
        private System.Windows.Forms.ListBox sayiListesiKarisikListBox;
        private System.Windows.Forms.ListBox sayiListesiSiraliListBox;
        private System.Windows.Forms.Button bubbleSortIleSiralaButton;
    }
}

