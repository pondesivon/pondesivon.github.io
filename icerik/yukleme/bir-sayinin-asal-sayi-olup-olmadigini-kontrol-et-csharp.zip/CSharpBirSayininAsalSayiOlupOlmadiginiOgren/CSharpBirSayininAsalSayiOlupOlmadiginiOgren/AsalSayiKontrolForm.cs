﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpBirSayininAsalSayiOlupOlmadiginiOgren
{
    public partial class AsalSayiKontrolForm : Form
    {
        public AsalSayiKontrolForm()
        {
            InitializeComponent();
        }

        int RasgeleSayiUret()
        {
            Random random = new Random();
            return random.Next(2, 32000000);
        }

        string AsalSayiKontrol(int sayi)
        {
            try
            {
                if (sayi < 2)
                {
                    return 
                        "En küçük asal sayı 2'den başlar. "
                        + "Lütfen buna göre bir tam sayı girişi yapın.";
                }
                else
                {
                    int sayac = 0;
                    string sonuc = "";
                    for (int i = 2; i <= sayi; i++)
                    {
                        if (sayi % i == 0 && sayi != i)
                        {
                            sayac = sayac + 1;
                            sonuc = sonuc + i.ToString() + ", ";
                        }
                    }

                    if (sayac == 0)
                    {
                        return 
                            "Girilen sayı asal sayıdır.";
                    }
                    else
                    {
                        return
                            "Girilen sayı asal sayı değildir.\n\n"
                            + "Girilen sayıyı bölebilen sayılar: \n"
                            + sonuc.Trim(", ".ToCharArray());
                    }
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        void EgerDegerGirisiYapilmissaIslemYap()
        {
            if (!String.IsNullOrEmpty(sayiRichTextBox.Text))
            {
                mesajRichTextBox.Text = AsalSayiKontrol(Convert.ToInt32(sayiRichTextBox.Text));
            }
        }

        private void AsalSayiKontrolForm_Load(object sender, EventArgs e)
        {
            sayiRichTextBox.Text = RasgeleSayiUret().ToString();
        }

        private void rasgeleSayiUretVeKontrolEtButton_Click(object sender, EventArgs e)
        {
            sayiRichTextBox.Text = RasgeleSayiUret().ToString();
            EgerDegerGirisiYapilmissaIslemYap();

        }

        private void sayininAsalSayiOlupOlmadiginiKontrolEtButton_Click(object sender, EventArgs e)
        {
            EgerDegerGirisiYapilmissaIslemYap();
        }
    }
}
