﻿
namespace CSharpBirSayininAsalSayiOlupOlmadiginiOgren
{
    partial class AsalSayiKontrolForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.kapsayiciTableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.sayiRichTextBox = new System.Windows.Forms.RichTextBox();
            this.altTableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.sayininAsalSayiOlupOlmadiginiKontrolEtButton = new System.Windows.Forms.Button();
            this.rasgeleSayiUretVeKontrolEtButton = new System.Windows.Forms.Button();
            this.mesajRichTextBox = new System.Windows.Forms.RichTextBox();
            this.kapsayiciTableLayoutPanel.SuspendLayout();
            this.altTableLayoutPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // kapsayiciTableLayoutPanel
            // 
            this.kapsayiciTableLayoutPanel.ColumnCount = 1;
            this.kapsayiciTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.kapsayiciTableLayoutPanel.Controls.Add(this.mesajRichTextBox, 0, 2);
            this.kapsayiciTableLayoutPanel.Controls.Add(this.sayiRichTextBox, 0, 0);
            this.kapsayiciTableLayoutPanel.Controls.Add(this.altTableLayoutPanel, 0, 1);
            this.kapsayiciTableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kapsayiciTableLayoutPanel.Location = new System.Drawing.Point(0, 0);
            this.kapsayiciTableLayoutPanel.Name = "kapsayiciTableLayoutPanel";
            this.kapsayiciTableLayoutPanel.RowCount = 3;
            this.kapsayiciTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.kapsayiciTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.kapsayiciTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 173F));
            this.kapsayiciTableLayoutPanel.Size = new System.Drawing.Size(483, 276);
            this.kapsayiciTableLayoutPanel.TabIndex = 0;
            // 
            // sayiRichTextBox
            // 
            this.sayiRichTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sayiRichTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sayiRichTextBox.Location = new System.Drawing.Point(3, 3);
            this.sayiRichTextBox.Multiline = false;
            this.sayiRichTextBox.Name = "sayiRichTextBox";
            this.sayiRichTextBox.Size = new System.Drawing.Size(477, 41);
            this.sayiRichTextBox.TabIndex = 0;
            this.sayiRichTextBox.Text = "15573";
            // 
            // altTableLayoutPanel
            // 
            this.altTableLayoutPanel.ColumnCount = 2;
            this.altTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.23972F));
            this.altTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.76027F));
            this.altTableLayoutPanel.Controls.Add(this.sayininAsalSayiOlupOlmadiginiKontrolEtButton, 0, 0);
            this.altTableLayoutPanel.Controls.Add(this.rasgeleSayiUretVeKontrolEtButton, 0, 0);
            this.altTableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.altTableLayoutPanel.Location = new System.Drawing.Point(3, 50);
            this.altTableLayoutPanel.Name = "altTableLayoutPanel";
            this.altTableLayoutPanel.RowCount = 1;
            this.altTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.altTableLayoutPanel.Size = new System.Drawing.Size(477, 50);
            this.altTableLayoutPanel.TabIndex = 2;
            // 
            // sayininAsalSayiOlupOlmadiginiKontrolEtButton
            // 
            this.sayininAsalSayiOlupOlmadiginiKontrolEtButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.sayininAsalSayiOlupOlmadiginiKontrolEtButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sayininAsalSayiOlupOlmadiginiKontrolEtButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sayininAsalSayiOlupOlmadiginiKontrolEtButton.Location = new System.Drawing.Point(314, 3);
            this.sayininAsalSayiOlupOlmadiginiKontrolEtButton.Name = "sayininAsalSayiOlupOlmadiginiKontrolEtButton";
            this.sayininAsalSayiOlupOlmadiginiKontrolEtButton.Size = new System.Drawing.Size(160, 44);
            this.sayininAsalSayiOlupOlmadiginiKontrolEtButton.TabIndex = 1;
            this.sayininAsalSayiOlupOlmadiginiKontrolEtButton.Text = "Asal Sayı Kontrol";
            this.sayininAsalSayiOlupOlmadiginiKontrolEtButton.UseVisualStyleBackColor = false;
            this.sayininAsalSayiOlupOlmadiginiKontrolEtButton.Click += new System.EventHandler(this.sayininAsalSayiOlupOlmadiginiKontrolEtButton_Click);
            // 
            // rasgeleSayiUretVeKontrolEtButton
            // 
            this.rasgeleSayiUretVeKontrolEtButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.rasgeleSayiUretVeKontrolEtButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rasgeleSayiUretVeKontrolEtButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rasgeleSayiUretVeKontrolEtButton.Location = new System.Drawing.Point(3, 3);
            this.rasgeleSayiUretVeKontrolEtButton.Name = "rasgeleSayiUretVeKontrolEtButton";
            this.rasgeleSayiUretVeKontrolEtButton.Size = new System.Drawing.Size(305, 44);
            this.rasgeleSayiUretVeKontrolEtButton.TabIndex = 0;
            this.rasgeleSayiUretVeKontrolEtButton.Text = "Rasgele Sayı Üret Ve Kontrol Et";
            this.rasgeleSayiUretVeKontrolEtButton.UseVisualStyleBackColor = false;
            this.rasgeleSayiUretVeKontrolEtButton.Click += new System.EventHandler(this.rasgeleSayiUretVeKontrolEtButton_Click);
            // 
            // mesajRichTextBox
            // 
            this.mesajRichTextBox.BackColor = System.Drawing.Color.White;
            this.mesajRichTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mesajRichTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.mesajRichTextBox.Location = new System.Drawing.Point(3, 106);
            this.mesajRichTextBox.Name = "mesajRichTextBox";
            this.mesajRichTextBox.Size = new System.Drawing.Size(477, 167);
            this.mesajRichTextBox.TabIndex = 3;
            this.mesajRichTextBox.Text = "";
            // 
            // AsalSayiKontrolForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(483, 276);
            this.Controls.Add(this.kapsayiciTableLayoutPanel);
            this.Name = "AsalSayiKontrolForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Asal Sayı Kontrol";
            this.Load += new System.EventHandler(this.AsalSayiKontrolForm_Load);
            this.kapsayiciTableLayoutPanel.ResumeLayout(false);
            this.altTableLayoutPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel kapsayiciTableLayoutPanel;
        private System.Windows.Forms.RichTextBox sayiRichTextBox;
        private System.Windows.Forms.TableLayoutPanel altTableLayoutPanel;
        private System.Windows.Forms.Button sayininAsalSayiOlupOlmadiginiKontrolEtButton;
        private System.Windows.Forms.Button rasgeleSayiUretVeKontrolEtButton;
        private System.Windows.Forms.RichTextBox mesajRichTextBox;
    }
}

