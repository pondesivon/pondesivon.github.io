<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<form action='yazdir.php' method='post'>
		<table>
			<tr>
				<td>Ad</td>
				<td>Soyad</td>
				<td>Eposta<td>
			</tr>

			<tr>
				<td><input name='ad' type='text'></td>
				<td><input name='soyad' type='text'></td>
				<td><input name='eposta' type='text'><td>
			</tr>
		</table>

		<input name='gonder' type='submit' value='Txt Dosyasına Aktar'>
	</form>
	<hr>
	<?php
		$ad = $_POST["ad"];
		$soyad = $_POST["soyad"];
		$e_posta = $_POST["eposta"];
				
		$dosya = fopen ("dosya.txt" , 'aw') or die('Bir hata oluştu.');
		$veri = $ad . "-" . $soyad . "-" . $e_posta . "\n";
		fwrite ( $dosya , $veri);
		fclose ($dosya);
		echo "<a href='dosya.txt'>dosya.txt</a>";
	?>	
</body>
</html>