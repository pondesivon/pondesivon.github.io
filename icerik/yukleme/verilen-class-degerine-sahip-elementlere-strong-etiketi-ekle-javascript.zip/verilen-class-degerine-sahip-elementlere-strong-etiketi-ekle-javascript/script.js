var listeOge = document.getElementsByClassName("sebze");

for (var i = 0; i < listeOge.length; i++) {
    listeOge[i].innerHTML = 
    	"<strong>" + listeOge[i].innerHTML + "</strong>";
}