//--------------------------------------------------
//Aktifleştir
//--------------------------------------------------
function TextAreaAktiflestir() {
	var deger = document.getElementById('aktiflestir-secenek');
	
	document.getElementById('pasiflestir-secenek').checked = false;
	
	if(deger.checked == true) {
		document.getElementById("metin-alani").disabled = false;
	}
}

//--------------------------------------------------
//Pasifleştir
//--------------------------------------------------
function TextAreaPasiflestir() {
	var deger = document.getElementById('pasiflestir-secenek');
	
	document.getElementById('aktiflestir-secenek').checked = false;
		
	if(deger.checked == true) {
		document.getElementById("metin-alani").disabled = true;
	}
}