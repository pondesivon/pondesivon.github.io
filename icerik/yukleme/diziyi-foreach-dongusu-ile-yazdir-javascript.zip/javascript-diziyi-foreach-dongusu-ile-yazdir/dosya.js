var numbers = [5, 10, 50, 100, 150, 200];

numbers.forEach(function(entry) {
    document.write(entry + "<br>");
});