function veri_gonder() {
	
	//ad ve soyad değişkenlerine name değeri "ad" ve
	//"soyad" ismine sahip "input" etiketlerinin "value"
	//değerlerini alıyoruz. Sizinde bildiğiniz gibi bizim
	//gireceğimiz isim ve soyisim input etiketinin value
	//kısmı oluyor.
	ad    = $('input[name="ad"]').val();
	soyad = $('input[name="soyad"]').val();
	
	
	//$.get() fonksiyonu çalışıyor. index.html dosyasındaki
	//name değeri "a" olan div etiketinin içine ismi yazdıracak.
	$.get('index.html', 
			{yazi: ad},
			function (gelen_cevap) { 
				$('div[name="adGelen"]').html(ad);
			});

		 
	//Yine $.get() fonksiyonu çalışıyor. index.html dosyasındaki
	//name değeri "s" olan div etiketinin içine soyismi yazdıracak.
	 $.get('index.html', 
			{yazi: soyad},
			function (gelen_cevap) { 
				$('div[name="soyadGelen"]').html(soyad);
			});
}