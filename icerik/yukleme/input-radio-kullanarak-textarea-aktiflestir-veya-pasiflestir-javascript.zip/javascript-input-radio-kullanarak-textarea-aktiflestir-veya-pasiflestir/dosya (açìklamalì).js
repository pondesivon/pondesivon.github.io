//--------------------------------------------------
//id değeri verilen textarea'yı 
//aktifleştiren fonksiyon.
//--------------------------------------------------
function TextAreaAktiflestir() {	
	
	//--------------------------------------------------
	//İlgili elementin id değerini al.
	//--------------------------------------------------
	var deger = document.getElementById('aktiflestir-secenek');
	
	//--------------------------------------------------
	//İki seçenekli bir işlem yapıyoruz. 
	//Diğer seçeneği seçebilmek için öncesinde
	//bir seçim yapılmışsa bunu temizlemek gerekiyor.
	//Temizlenmesini istediğimiz elementi id değeri
	//aracılığıyla tespit edip seçimini temizle. 
	//--------------------------------------------------
	document.getElementById('pasiflestir-secenek').checked = false;
	
	//--------------------------------------------------
	//Aktifleştirme işlemini yapacak 
	//input radio seçilmişse işlem yap.
	//--------------------------------------------------
	if(deger.checked == true) {

		//--------------------------------------------------
		//İlgili textarea'nın disabled özelliğini
		//false yaparak aktifleştirme işlemini yap.
		//--------------------------------------------------
		document.getElementById("metin-alani").disabled = false;
	}
}



//--------------------------------------------------
//id değeri verilen textarea'yı 
//pasifleştiren fonksiyon.
//--------------------------------------------------
function TextAreaPasiflestir() {	

	//--------------------------------------------------
	//İlgili elementin id değerini al.
	//--------------------------------------------------
	var deger = document.getElementById('pasiflestir-secenek');
	
	//--------------------------------------------------
	//İki seçenekli bir işlem yapıyoruz. 
	//Diğer seçeneği seçebilmek için öncesinde
	//bir seçim yapılmışsa bunu temizlemek gerekiyor.
	//Temizlenmesini istediğimiz elementi id değeri
	//aracılığıyla tespit edip seçimini temizle. 
	//--------------------------------------------------
	document.getElementById('aktiflestir-secenek').checked = false;

	//--------------------------------------------------
	//Pasifleştirme işlemini yapacak 
	//input radio seçilmişse işlem yap.
	//--------------------------------------------------
	if(deger.checked == true) {

		//--------------------------------------------------
		//İlgili textarea'nın disabled özelliğini
		//false yaparak pasifleştirme işlemini yap.
		//--------------------------------------------------
		document.getElementById("metin-alani").disabled = true;
	}
}