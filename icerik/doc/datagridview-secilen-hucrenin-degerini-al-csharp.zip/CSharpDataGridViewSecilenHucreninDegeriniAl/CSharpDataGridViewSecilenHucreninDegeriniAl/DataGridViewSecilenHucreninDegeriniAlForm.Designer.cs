﻿
namespace CSharpDataGridViewSecilenHucreninDegeriniAl
{
    partial class DataGridViewSecilenHucreninDegeriniAlForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.kapsayiciToolStripContainer = new System.Windows.Forms.ToolStripContainer();
            this.altToolStrip = new System.Windows.Forms.ToolStrip();
            this.bilgiToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.icerikDataGridView = new System.Windows.Forms.DataGridView();
            this.kapsayiciToolStripContainer.BottomToolStripPanel.SuspendLayout();
            this.kapsayiciToolStripContainer.ContentPanel.SuspendLayout();
            this.kapsayiciToolStripContainer.SuspendLayout();
            this.altToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.icerikDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // kapsayiciToolStripContainer
            // 
            // 
            // kapsayiciToolStripContainer.BottomToolStripPanel
            // 
            this.kapsayiciToolStripContainer.BottomToolStripPanel.Controls.Add(this.altToolStrip);
            // 
            // kapsayiciToolStripContainer.ContentPanel
            // 
            this.kapsayiciToolStripContainer.ContentPanel.Controls.Add(this.icerikDataGridView);
            this.kapsayiciToolStripContainer.ContentPanel.Size = new System.Drawing.Size(445, 236);
            this.kapsayiciToolStripContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kapsayiciToolStripContainer.Location = new System.Drawing.Point(0, 0);
            this.kapsayiciToolStripContainer.Name = "kapsayiciToolStripContainer";
            this.kapsayiciToolStripContainer.Size = new System.Drawing.Size(445, 292);
            this.kapsayiciToolStripContainer.TabIndex = 0;
            this.kapsayiciToolStripContainer.Text = "toolStripContainer1";
            // 
            // altToolStrip
            // 
            this.altToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.altToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bilgiToolStripLabel});
            this.altToolStrip.Location = new System.Drawing.Point(0, 0);
            this.altToolStrip.Name = "altToolStrip";
            this.altToolStrip.Size = new System.Drawing.Size(445, 31);
            this.altToolStrip.Stretch = true;
            this.altToolStrip.TabIndex = 0;
            // 
            // bilgiToolStripLabel
            // 
            this.bilgiToolStripLabel.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bilgiToolStripLabel.Name = "bilgiToolStripLabel";
            this.bilgiToolStripLabel.Size = new System.Drawing.Size(96, 28);
            this.bilgiToolStripLabel.Text = "Merhaba!";
            // 
            // icerikDataGridView
            // 
            this.icerikDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.icerikDataGridView.DefaultCellStyle = dataGridViewCellStyle1;
            this.icerikDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.icerikDataGridView.Location = new System.Drawing.Point(0, 0);
            this.icerikDataGridView.Name = "icerikDataGridView";
            this.icerikDataGridView.Size = new System.Drawing.Size(445, 236);
            this.icerikDataGridView.TabIndex = 0;
            this.icerikDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.icerikDataGridView_CellClick);
            // 
            // DataGridViewIstenilenHucreninDegeriniAlForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(445, 292);
            this.Controls.Add(this.kapsayiciToolStripContainer);
            this.Name = "DataGridViewIstenilenHucreninDegeriniAlForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DataGridView Seçilen Hücrenin Değerini Al";
            this.Load += new System.EventHandler(this.DataGridViewIstenilenHucreninDegeriniAlForm_Load);
            this.kapsayiciToolStripContainer.BottomToolStripPanel.ResumeLayout(false);
            this.kapsayiciToolStripContainer.BottomToolStripPanel.PerformLayout();
            this.kapsayiciToolStripContainer.ContentPanel.ResumeLayout(false);
            this.kapsayiciToolStripContainer.ResumeLayout(false);
            this.kapsayiciToolStripContainer.PerformLayout();
            this.altToolStrip.ResumeLayout(false);
            this.altToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.icerikDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStripContainer kapsayiciToolStripContainer;
        private System.Windows.Forms.ToolStrip altToolStrip;
        private System.Windows.Forms.ToolStripLabel bilgiToolStripLabel;
        private System.Windows.Forms.DataGridView icerikDataGridView;
    }
}

