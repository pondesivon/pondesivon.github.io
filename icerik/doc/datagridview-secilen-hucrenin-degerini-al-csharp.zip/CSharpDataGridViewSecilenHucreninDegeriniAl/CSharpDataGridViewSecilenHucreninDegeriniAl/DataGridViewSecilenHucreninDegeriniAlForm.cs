﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpDataGridViewSecilenHucreninDegeriniAl
{
    public partial class DataGridViewSecilenHucreninDegeriniAlForm : Form
    {
        public DataGridViewSecilenHucreninDegeriniAlForm()
        {
            InitializeComponent();
        }

        private string SeciliHucreIleIlgiliBilgileriGetir_CellClick(
            DataGridView dataGridView, object sender, DataGridViewCellEventArgs e)
        {
            return 
                "[" + dataGridView.CurrentCell.RowIndex
                + ". SATIR][" 
                + dataGridView.CurrentCell.ColumnIndex
                + ". SÜTUN]"
                + "[DEĞER: "
                + dataGridView.CurrentCell.Value.ToString() + "]";
        }

        void DataGridViewUzerineRasgeleDegerlerEkle(DataGridView dataGridView)
        {
            DataTable dt = new DataTable();

            dt.Columns.Add("A");
            dt.Columns.Add("B");
            dt.Columns.Add("C");
            dt.Columns.Add("D");
            dt.Columns.Add("E");

            Random r = new Random();

            for (int i = 1; i <= 5; i++)
            {
                dt.Rows.Add(
                    r.Next(1, 1000),
                    r.Next(1, 1000),
                    r.Next(1, 1000),
                    r.Next(1, 1000),
                    r.Next(1, 1000));
            }

            dataGridView.DataSource = dt;
            dataGridView.AutoResizeColumns();
            dataGridView.AutoResizeRows();
        }

        private void DataGridViewIstenilenHucreninDegeriniAlForm_Load(object sender, EventArgs e)
        {
            DataGridViewUzerineRasgeleDegerlerEkle(icerikDataGridView);
        }

        private void icerikDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            bilgiToolStripLabel.Text =
                SeciliHucreIleIlgiliBilgileriGetir_CellClick(icerikDataGridView, sender, e);
        }
    }
}
