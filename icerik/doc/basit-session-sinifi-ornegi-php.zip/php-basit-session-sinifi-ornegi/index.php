<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8" />
</head>

<body>

	<?php
		require_once("SessionManagement.php");

		//--------------------------------------------------
		//Sınıfın örneğini oluştur.
		//--------------------------------------------------
		$oturum = new SessionManagement();

		//--------------------------------------------------
		//Oturumu başlat.
		//--------------------------------------------------
		$oturum->session_baslat();

		//--------------------------------------------------
		//Oturum ile ilgili değişkenleri ayarla.
		//--------------------------------------------------
		$s_dizi = array("anahtar_1" => "deger_1",
						"anahtar_2" => "deger_2",
					    //...
					    "anahtar_n" => "deger_n"
					   );

		//--------------------------------------------------
		//Oturumu oluştur.
		//--------------------------------------------------
		$oturum->session_olustur($s_dizi);

		//--------------------------------------------------
		//Oturum değişkenlerinin değerlerini sıfırla.
		//--------------------------------------------------
		$oturum->session_sifirla();

		//--------------------------------------------------
		//Oturumu sonlandır.
		//--------------------------------------------------
		$oturum->session_bitir();
	?>
</body>
</html>