<?php
	class SessionManagement {
		public function session_baslat() {
			return session_start();
		}

		public function session($par) {
			if(isset($_SESSION[$par])) {
				return $_SESSION[$par];
			} else {
				return false;
			}
		}

		public function session_olustur($par) {
			foreach($par as $anahtar=>$deger) {
				$_SESSION[$anahtar] = $deger;
			}
		}

		public function session_sifirla() {
			return session_unset();
		}

		public function session_bitir() {
			return session_destroy();
		}
	}