﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpDataGridViewIlkVeyaSonVeriyiSecVeIlgiliSatiraGit
{
    public partial class DataGridViewSatirSecForm : Form
    {
        public DataGridViewSatirSecForm()
        {
            InitializeComponent();
        }

        void IlkSatiraGitDataGridView(DataGridView dataGridView)
        {
            dataGridView.ClearSelection();
            dataGridView.Rows[0].Cells[0].Selected = true;
            dataGridView.FirstDisplayedScrollingRowIndex = 0;
        }

        void SonSatiraGitDataGridView(DataGridView dataGridView)
        {
            int a = Convert.ToInt32(dataGridView.Rows.Count);
            dataGridView.ClearSelection();
            dataGridView.Rows[a - 2].Selected = true;
            dataGridView.FirstDisplayedScrollingRowIndex = dataGridView.RowCount - 1;
        }

        void DegerEkleDataGridView(DataGridView dataGridView)
        {
            DataTable dt = new DataTable();

            dt.Columns.Add("A");

            Random r = new Random();

            for (int i = 1; i <= 100; i++)
            {
                dt.Rows.Add(r.Next(1, 1000));
            }

            dataGridView.DataSource = dt;
            
            dataGridView.AutoResizeColumns();
            dataGridView.AutoResizeRows();
        }

        private void DataGridViewSatirSecForm_Load(object sender, EventArgs e)
        {
            DegerEkleDataGridView(icerikDataGridView);
        }

        private void ilkSatiraGitButton_Click(object sender, EventArgs e)
        {
            IlkSatiraGitDataGridView(icerikDataGridView);
        }

        private void sonSatiraGitButton_Click(object sender, EventArgs e)
        {
            SonSatiraGitDataGridView(icerikDataGridView);
        }
    }
}
