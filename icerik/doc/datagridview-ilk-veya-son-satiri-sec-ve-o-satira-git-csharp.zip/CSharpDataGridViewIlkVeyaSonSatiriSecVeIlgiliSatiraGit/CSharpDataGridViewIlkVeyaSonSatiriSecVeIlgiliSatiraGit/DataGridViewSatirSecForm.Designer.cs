﻿
namespace CSharpDataGridViewIlkVeyaSonVeriyiSecVeIlgiliSatiraGit
{
    partial class DataGridViewSatirSecForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.icerikDataGridView = new System.Windows.Forms.DataGridView();
            this.kapsayiciTableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.altTableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.ilkSatiraGitButton = new System.Windows.Forms.Button();
            this.sonSatiraGitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.icerikDataGridView)).BeginInit();
            this.kapsayiciTableLayoutPanel.SuspendLayout();
            this.altTableLayoutPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // icerikDataGridView
            // 
            this.icerikDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.icerikDataGridView.DefaultCellStyle = dataGridViewCellStyle2;
            this.icerikDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.icerikDataGridView.Location = new System.Drawing.Point(3, 3);
            this.icerikDataGridView.Name = "icerikDataGridView";
            this.icerikDataGridView.Size = new System.Drawing.Size(391, 227);
            this.icerikDataGridView.TabIndex = 0;
            // 
            // kapsayiciTableLayoutPanel
            // 
            this.kapsayiciTableLayoutPanel.ColumnCount = 1;
            this.kapsayiciTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.kapsayiciTableLayoutPanel.Controls.Add(this.icerikDataGridView, 0, 0);
            this.kapsayiciTableLayoutPanel.Controls.Add(this.altTableLayoutPanel, 0, 1);
            this.kapsayiciTableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kapsayiciTableLayoutPanel.Location = new System.Drawing.Point(0, 0);
            this.kapsayiciTableLayoutPanel.Name = "kapsayiciTableLayoutPanel";
            this.kapsayiciTableLayoutPanel.RowCount = 2;
            this.kapsayiciTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.kapsayiciTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 66F));
            this.kapsayiciTableLayoutPanel.Size = new System.Drawing.Size(397, 299);
            this.kapsayiciTableLayoutPanel.TabIndex = 1;
            // 
            // altTableLayoutPanel
            // 
            this.altTableLayoutPanel.ColumnCount = 2;
            this.altTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.altTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.altTableLayoutPanel.Controls.Add(this.ilkSatiraGitButton, 0, 0);
            this.altTableLayoutPanel.Controls.Add(this.sonSatiraGitButton, 1, 0);
            this.altTableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.altTableLayoutPanel.Location = new System.Drawing.Point(3, 236);
            this.altTableLayoutPanel.Name = "altTableLayoutPanel";
            this.altTableLayoutPanel.RowCount = 1;
            this.altTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.altTableLayoutPanel.Size = new System.Drawing.Size(391, 60);
            this.altTableLayoutPanel.TabIndex = 1;
            // 
            // ilkSatiraGitButton
            // 
            this.ilkSatiraGitButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ilkSatiraGitButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ilkSatiraGitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ilkSatiraGitButton.Location = new System.Drawing.Point(3, 3);
            this.ilkSatiraGitButton.Name = "ilkSatiraGitButton";
            this.ilkSatiraGitButton.Size = new System.Drawing.Size(189, 55);
            this.ilkSatiraGitButton.TabIndex = 0;
            this.ilkSatiraGitButton.Text = "İlk Satıra Git";
            this.ilkSatiraGitButton.UseVisualStyleBackColor = false;
            this.ilkSatiraGitButton.Click += new System.EventHandler(this.ilkSatiraGitButton_Click);
            // 
            // sonSatiraGitButton
            // 
            this.sonSatiraGitButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.sonSatiraGitButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sonSatiraGitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sonSatiraGitButton.Location = new System.Drawing.Point(198, 3);
            this.sonSatiraGitButton.Name = "sonSatiraGitButton";
            this.sonSatiraGitButton.Size = new System.Drawing.Size(190, 55);
            this.sonSatiraGitButton.TabIndex = 0;
            this.sonSatiraGitButton.Text = "Son Satıra Git";
            this.sonSatiraGitButton.UseVisualStyleBackColor = false;
            this.sonSatiraGitButton.Click += new System.EventHandler(this.sonSatiraGitButton_Click);
            // 
            // DataGridViewSatirSecForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(397, 299);
            this.Controls.Add(this.kapsayiciTableLayoutPanel);
            this.Name = "DataGridViewSatirSecForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DataGridView İlk Veya Son Satırı Seç Ve O Satıra Git";
            this.Load += new System.EventHandler(this.DataGridViewSatirSecForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.icerikDataGridView)).EndInit();
            this.kapsayiciTableLayoutPanel.ResumeLayout(false);
            this.altTableLayoutPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView icerikDataGridView;
        private System.Windows.Forms.TableLayoutPanel kapsayiciTableLayoutPanel;
        private System.Windows.Forms.TableLayoutPanel altTableLayoutPanel;
        private System.Windows.Forms.Button ilkSatiraGitButton;
        private System.Windows.Forms.Button sonSatiraGitButton;
    }
}

