//--------------------------------------------------
//id değeri "meyve-ekle" olan element için olay 
//atamasını addEventListener ile javascript 
//dosyası üzerinden yaptık.
//--------------------------------------------------
document.getElementById("meyve-ekle").addEventListener(
	//--------------------------------------------------
	//Bu kod ilgili elementin click olayında çalışacak.
	//--------------------------------------------------
	'click',
	
	//--------------------------------------------------
	//click olayı olduğunda aşağıdaki fonksiyon çalışacak.
	//--------------------------------------------------
	function meyveEkle() {
		
		//--------------------------------------------------
		//kutu id değerine sahip input elementine değişken 
		//ataması yaptım. ol ve li için değerler bu inputtan 
		//gidecek.
		//--------------------------------------------------
		var jkutu = document.getElementById("kutu");
		
		//--------------------------------------------------
		//ol elementi sayfada var mı önce onu kontrol ediyoruz.
		//Varsa ekliyor, yoksa ol içine li ekleme işine geçecek.
		//--------------------------------------------------
		if(document.getElementById("meyveler") === null) {
			
			//--------------------------------------------------
			//Yoksa ol elementi oluşturuluyor.
			//--------------------------------------------------
			var olElement = document.createElement("ol");
			
			//--------------------------------------------------
			//ol elementi için id attribute değerini ayarladım.
			//--------------------------------------------------
			olElement.id = "meyveler";

			//--------------------------------------------------
			//div içine element ekleme
			//liste id değerine sahip elementi bul (bu bir div) ve
			//olElement değişkenini ekle. Böylelikle div içine ol
			//elementi eklemiş olduk.
			//--------------------------------------------------
			document.getElementById("liste").appendChild(olElement);
		}
		
		//--------------------------------------------------
		//Zaten bir ol elementi daha önceden 
		//oluşturulmuşsa buradan devam edecek.
		//Yani artık li elementlerini ekleyeceğiz.
		//Öncelikle bir li elementi oluşturalım.
		//--------------------------------------------------
		var liElement = document.createElement("li");
		
		//--------------------------------------------------
		//li elementinin iç kısmına <li>BURASI OLUYOR.</li>
		//input elementinden gelen veriyi aktarmak gerek.
		//Bu işlemi gerçekleştiriyoruz.
		//--------------------------------------------------
		liElement.innerHTML = jkutu.value;
		
		//--------------------------------------------------
		//ol elementinin içine li ekleme işlemini yaptık.
		//Dikkat edin oluşturduğumuz li elementi ol elementine ekleniyor.
		//liste id değerine sahip div
		//kodla oluşturduğumuz meyveler id değerine sahip ol [li buraya ekleniyor]
		//--------------------------------------------------
		document.getElementById("meyveler").appendChild(liElement);
		
		//--------------------------------------------------
		//input içindeki veriyi temizliyoruz.
		//--------------------------------------------------
		jkutu.value = "";
		
		//--------------------------------------------------
		//İmlecin tekrardan input elementinde 
		//aktif olmasını sağlıyoruz.
		//--------------------------------------------------
		jkutu.focus();
	}
);