document.getElementById("meyve-ekle").addEventListener(
	'click', 
	function meyveEkle() {
		
		var jkutu = document.getElementById("kutu");
		
		if(document.getElementById("meyveler") === null) {
			var olElement = document.createElement("ol");
			olElement.id = "meyveler";

			document.getElementById("liste").appendChild(olElement);
		}

		var liElement = document.createElement("li");
		liElement.innerHTML = jkutu.value;
		document.getElementById("meyveler").appendChild(liElement);
		jkutu.value = "";
		jkutu.focus();
	}
);