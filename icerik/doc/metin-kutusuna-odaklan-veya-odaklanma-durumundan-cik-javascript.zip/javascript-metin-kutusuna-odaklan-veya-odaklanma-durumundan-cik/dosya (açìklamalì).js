//--------------------------------------------------
//Metin kutusuna odaklanma işlemini
//yaptırmak için fonsiyon yazdık.
//--------------------------------------------------
function metinKutusuOdaklan() {
  document.getElementById("metin-kutusu").focus();
}

//--------------------------------------------------
//Metin kutusunaki odaklanma işlemini
//kaldırmak için fonsiyon yazdık.
//--------------------------------------------------
function metinKutusuOdaklanmaDurumundanCik() {
  document.getElementById("metin-kutusu").blur();
}

//--------------------------------------------------
//HTML dosyasında iki farklı id'li buton vardı: 
//odaklan ve cik. odaklan butonunda metin kutusuna 
//focus işlemini click olayı için yaptırıyoruz.
//--------------------------------------------------
document.getElementById("odaklan").addEventListener(
  'click',
  metinKutusuOdaklan
);

//--------------------------------------------------
//HTML dosyasında iki farklı id'li buton vardı: 
//odaklan ve cik. cik butonunda focus işlemini 
//iptal ediyoruz ya da focus halinden çıkıyoruz.
//--------------------------------------------------
document.getElementById("cik").addEventListener(
  'click',
  metinKutusuOdaklanmaDurumundanCik
);