//--------------------------------------------------
//function Grubu
//--------------------------------------------------
function metinKutusuOdaklan() {
  document.getElementById("metin-kutusu").focus();
}

function metinKutusuOdaklanmaDurumundanCik() {
  document.getElementById("metin-kutusu").blur();
}

//--------------------------------------------------
//addEventListener Grubu
//--------------------------------------------------
document.getElementById("odaklan").addEventListener(
  'click',
  metinKutusuOdaklan
);

document.getElementById("cik").addEventListener(
  'click',
  metinKutusuOdaklanmaDurumundanCik
);