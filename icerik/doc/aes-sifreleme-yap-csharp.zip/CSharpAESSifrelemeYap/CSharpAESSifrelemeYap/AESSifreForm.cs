﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpAESSifrelemeYap
{
    public partial class AESSifreForm : Form
    {
        public AESSifreForm()
        {
            InitializeComponent();
        }

        private void sifreleButton_Click(object sender, EventArgs e)
        {
            string sifrelenmisMetin = AES.Sifrele(metinRichTextBox.Text);
            metinRichTextBox.Text = sifrelenmisMetin;
        }

        private void sifreCozButton_Click(object sender, EventArgs e)
        {
            string sifresiCozulmusMetin = AES.SifreCoz(metinRichTextBox.Text);
            metinRichTextBox.Text = sifresiCozulmusMetin;
        }
    }
}