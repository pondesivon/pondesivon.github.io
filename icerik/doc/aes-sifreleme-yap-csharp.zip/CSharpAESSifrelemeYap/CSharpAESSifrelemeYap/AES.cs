﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace CSharpAESSifrelemeYap
{
    class AES
    {
        private const string AES_IV = @"!&+QWSDF!123126+";
        private static string aes_anahtar = @"QQsaw!257()%%ert";

        public static AesCryptoServiceProvider AESSaglayici { get; set; } =
            new AesCryptoServiceProvider();

        public static string Sifrele(string metin)
        {
            AESSaglayici.BlockSize = 128;
            AESSaglayici.KeySize = 128;
            AESSaglayici.IV = Encoding.UTF8.GetBytes(AES_IV);
            AESSaglayici.Key = Encoding.UTF8.GetBytes(aes_anahtar);
            AESSaglayici.Mode = CipherMode.CBC;
            AESSaglayici.Padding = PaddingMode.PKCS7;

            byte[] kaynak = Encoding.Unicode.GetBytes(metin);

            using (ICryptoTransform sifrele = AESSaglayici.CreateEncryptor())
            {
                byte[] hedef = sifrele.TransformFinalBlock(kaynak, 0, kaynak.Length);
                return Convert.ToBase64String(hedef);
            }
        }


        public static string SifreCoz(string sifreliMetin)
        {
            AesCryptoServiceProvider AESSaglayici = new AesCryptoServiceProvider();
            AESSaglayici.BlockSize = 128;
            AESSaglayici.KeySize = 128;
            AESSaglayici.IV = Encoding.UTF8.GetBytes(AES_IV);
            AESSaglayici.Key = Encoding.UTF8.GetBytes(aes_anahtar);
            AESSaglayici.Mode = CipherMode.CBC;
            AESSaglayici.Padding = PaddingMode.PKCS7;

            byte[] kaynak = System.Convert.FromBase64String(sifreliMetin);

            using (ICryptoTransform decrypt = AESSaglayici.CreateDecryptor())
            {
                byte[] hedef = decrypt.TransformFinalBlock(kaynak, 0, kaynak.Length);
                return Encoding.Unicode.GetString(hedef);
            }
        }
    }
}