﻿
namespace CSharpAESSifrelemeYap
{
    partial class AESSifreForm
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.kapsayiciTableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.metinRichTextBox = new System.Windows.Forms.RichTextBox();
            this.altTableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.sifreCozButton = new System.Windows.Forms.Button();
            this.sifreleButton = new System.Windows.Forms.Button();
            this.bilgiLabel = new System.Windows.Forms.Label();
            this.kapsayiciTableLayoutPanel.SuspendLayout();
            this.altTableLayoutPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // kapsayiciTableLayoutPanel
            // 
            this.kapsayiciTableLayoutPanel.ColumnCount = 1;
            this.kapsayiciTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.kapsayiciTableLayoutPanel.Controls.Add(this.metinRichTextBox, 0, 0);
            this.kapsayiciTableLayoutPanel.Controls.Add(this.altTableLayoutPanel, 0, 1);
            this.kapsayiciTableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kapsayiciTableLayoutPanel.Location = new System.Drawing.Point(0, 0);
            this.kapsayiciTableLayoutPanel.Name = "kapsayiciTableLayoutPanel";
            this.kapsayiciTableLayoutPanel.RowCount = 2;
            this.kapsayiciTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.kapsayiciTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.kapsayiciTableLayoutPanel.Size = new System.Drawing.Size(603, 346);
            this.kapsayiciTableLayoutPanel.TabIndex = 0;
            // 
            // metinRichTextBox
            // 
            this.metinRichTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metinRichTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.metinRichTextBox.Location = new System.Drawing.Point(3, 3);
            this.metinRichTextBox.Name = "metinRichTextBox";
            this.metinRichTextBox.Size = new System.Drawing.Size(597, 279);
            this.metinRichTextBox.TabIndex = 0;
            this.metinRichTextBox.Text = "Ali ata bak.";
            // 
            // altTableLayoutPanel
            // 
            this.altTableLayoutPanel.ColumnCount = 3;
            this.altTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.altTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 125F));
            this.altTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121F));
            this.altTableLayoutPanel.Controls.Add(this.sifreCozButton, 0, 0);
            this.altTableLayoutPanel.Controls.Add(this.sifreleButton, 0, 0);
            this.altTableLayoutPanel.Controls.Add(this.bilgiLabel, 0, 0);
            this.altTableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.altTableLayoutPanel.Location = new System.Drawing.Point(3, 288);
            this.altTableLayoutPanel.Name = "altTableLayoutPanel";
            this.altTableLayoutPanel.RowCount = 1;
            this.altTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.altTableLayoutPanel.Size = new System.Drawing.Size(597, 55);
            this.altTableLayoutPanel.TabIndex = 1;
            // 
            // sifreCozButton
            // 
            this.sifreCozButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.sifreCozButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sifreCozButton.Location = new System.Drawing.Point(479, 3);
            this.sifreCozButton.Name = "sifreCozButton";
            this.sifreCozButton.Size = new System.Drawing.Size(115, 49);
            this.sifreCozButton.TabIndex = 12;
            this.sifreCozButton.Text = "ŞİFRE ÇÖZ";
            this.sifreCozButton.UseVisualStyleBackColor = false;
            this.sifreCozButton.Click += new System.EventHandler(this.sifreCozButton_Click);
            // 
            // sifreleButton
            // 
            this.sifreleButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.sifreleButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sifreleButton.Location = new System.Drawing.Point(354, 3);
            this.sifreleButton.Name = "sifreleButton";
            this.sifreleButton.Size = new System.Drawing.Size(119, 49);
            this.sifreleButton.TabIndex = 11;
            this.sifreleButton.Text = "ŞİFRELE";
            this.sifreleButton.UseVisualStyleBackColor = false;
            this.sifreleButton.Click += new System.EventHandler(this.sifreleButton_Click);
            // 
            // bilgiLabel
            // 
            this.bilgiLabel.AutoSize = true;
            this.bilgiLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bilgiLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bilgiLabel.Location = new System.Drawing.Point(3, 0);
            this.bilgiLabel.Name = "bilgiLabel";
            this.bilgiLabel.Size = new System.Drawing.Size(345, 55);
            this.bilgiLabel.TabIndex = 10;
            this.bilgiLabel.Text = "Üst kısma şifrelenecek metni girin, \r\nŞİFRELE butonuna basarak şifreleyebilirsini" +
    "z, \r\nŞİFRE ÇÖZ butonuna basarak şifreyi çözebilirsiniz.";
            // 
            // AESSifreForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(603, 346);
            this.Controls.Add(this.kapsayiciTableLayoutPanel);
            this.Name = "AESSifreForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AES Şifreleme Yap";
            this.kapsayiciTableLayoutPanel.ResumeLayout(false);
            this.altTableLayoutPanel.ResumeLayout(false);
            this.altTableLayoutPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel kapsayiciTableLayoutPanel;
        private System.Windows.Forms.RichTextBox metinRichTextBox;
        private System.Windows.Forms.TableLayoutPanel altTableLayoutPanel;
        private System.Windows.Forms.Button sifreCozButton;
        private System.Windows.Forms.Button sifreleButton;
        private System.Windows.Forms.Label bilgiLabel;
    }
}

